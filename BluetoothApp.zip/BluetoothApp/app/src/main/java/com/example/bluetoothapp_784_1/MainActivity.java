package com.example.bluetoothapp_784_1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private final static int REQUEST_CONNECT_DEVICE = 1;    //宏定义查询设备句柄
    private final static String MY_UUID = "00001101-0000-1000-8000-00805F9B34FB";   //SPP服务UUID号
    BluetoothDevice _device = null;     //蓝牙设备
    private BluetoothSocket _socket;
    boolean bRun = true;
    boolean bThread = false;
    private InputStream is;    //输入流，用来接收蓝牙数据
    private int setHeartrateMinValue=60;
    private int setHeartrateMaxValue=120;
    private int setSpo2MinValue=80;
    private float setTempMinValue= 15.0F;
    private float setTempMaxValue= 37.3F;
    private int setLengthValue=40;
    private float setMileageValue= 1.00F;
    private String smsg = "";    //显示用数据缓存

    private BluetoothAdapter _bluetooth = BluetoothAdapter.getDefaultAdapter();    //获取本地蓝牙适配器，即蓝牙设备

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //注意：蓝牙扫描之前必须开启GPS才能成功扫描！
        List<String> permissionList = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionList.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (!permissionList.isEmpty()) {
            String[] permissions = permissionList.toArray(new String[permissionList.size()]);
            ActivityCompat.requestPermissions(MainActivity.this, permissions, 1);
        }

        //如果打开本地蓝牙设备不成功，提示信息，结束程序
        if (_bluetooth == null){
            Toast.makeText(this, "无法打开手机蓝牙，请确认手机是否有蓝牙功能！", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        // 设置设备可以被搜索
        new Thread(){
            @SuppressLint("MissingPermission")
            public void run(){
                if(_bluetooth.isEnabled()==false) {
                    _bluetooth.enable();
                }
            }
        }.start();

    }


    /**
     * 重写事件分发
     */
    @Override
    public  boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            View v = getCurrentFocus();
            if (isShouldHideKeyboard(v, ev)) {
                v.clearFocus();//清除Edittext的焦点从而让光标消失
                hideKeyboard(v.getWindowToken());
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    /**
     * 根据EditText所在坐标和用户点击的坐标相对比，来判断是否隐藏键盘，因为当用户点击EditText时则不能隐藏
     * @param v
     * @param event
     * @return
     */
    private boolean isShouldHideKeyboard(View v, MotionEvent event) {
        boolean vinstanceof;
        if (v !=null && (v instanceof EditText)) {
            int[] l = {0, 0};
            v.getLocationOnScreen(l);;
            int left = l[0],
                    top = l[1],
                    bottom = top + v.getHeight(),
                    right = left + v.getWidth();
            if (event.getRawX() > left &&event.getRawX() < right
                    && event.getRawY()> top && event.getRawY() < bottom) {
                //点击EditText的时候不做隐藏处理
                return false;
            } else {
                return true;
            }
        }
        //如果焦点不是EditText则忽略，这个发生在视图刚绘制完，第一个焦点不在EditText上，和用户用轨迹球选择其他的焦点
        return false;
    }

    /**
     * 获取InputMethodManager，隐藏软键盘
     * @param token
     */
    private void hideKeyboard(IBinder token) {

        if (token !=null) {
            //若token不为空则获取输入法管理器使其隐藏输入法键盘
            InputMethodManager im =(InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            im.hideSoftInputFromWindow(token,InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    //接收活动结果，响应startActivityForResult()
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch(requestCode){
            case REQUEST_CONNECT_DEVICE:     //连接结果，由DeviceListActivity设置返回
                // 响应返回结果
                if (resultCode == Activity.RESULT_OK) {   //连接成功，由DeviceListActivity设置返回
                    // MAC地址，由DeviceListActivity设置返回
                    String address = data.getExtras()
                            .getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
                    // 得到蓝牙设备句柄
                    _device = _bluetooth.getRemoteDevice(address);

                    // 用服务号得到socket
                    try{
                        _socket = _device.createRfcommSocketToServiceRecord(UUID.fromString(MY_UUID));
                    }catch(IOException e){
                        Toast.makeText(this, "连接失败！", Toast.LENGTH_SHORT).show();
                    }
                    //连接socket
                    try{
                        _socket.connect();
                        Toast.makeText(this, "连接"+_device.getName()+"成功！", Toast.LENGTH_SHORT).show();
                    }catch(IOException e){
                        try{
                            Toast.makeText(this, "连接失败！", Toast.LENGTH_SHORT).show();
                            _socket.close();
                            _socket = null;
                        }catch(IOException ee){
                            Toast.makeText(this, "连接失败！", Toast.LENGTH_SHORT).show();
                        }

                        return;
                    }

                    //打开接收线程
                    try{
                        is = _socket.getInputStream();   //得到蓝牙数据输入流
                    }catch(IOException e){
                        Toast.makeText(this, "接收数据失败！", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(bThread==false){
                        readThread.start();
                        bThread=true;
                    }else{
                        bRun = true;
                    }
                }
                break;
            default:break;
        }
    }

    //接收数据线程
    Thread readThread=new Thread(){

        public void run(){
            int num = 0;
            byte[] buffer = new byte[1024];
            byte[] buffer_new = new byte[1024];
            int i = 0;
            int n = 0;
            bRun = true;
            //接收线程
            while(true){
                try{
                    while(is.available()==0){
                        while(bRun == false){}
                    }
                    while(true){
                        if(!bThread)//跳出循环
                            return;

                        num = is.read(buffer);         //读入数据
                        n=0;

                        for(i=0;i<num;i++){
                            if((buffer[i] == 0x0d)&&(buffer[i+1]==0x0a)){
                                buffer_new[n] = 0x0a;
                                i++;
                            }else{
                                buffer_new[n] = buffer[i];
                            }
                            n++;
                        }
                        String s = new String(buffer_new,0,n);
                        smsg=s;   //写入接收缓存
                        if(is.available()==0)break;  //短时间没有数据才跳出进行显示
                    }
                    //发送显示消息，进行显示刷新
                    handler.sendMessage(handler.obtainMessage());
                }catch(IOException e){
                }
            }
        }
    };

    //消息处理队列
    @SuppressLint("HandlerLeak")
    Handler handler= new Handler(){
        public void handleMessage(Message msg){
            super.handleMessage(msg);
            try {
                int intIndex1 = smsg.indexOf("$Heartrate:");
                if(intIndex1!=-1) {
                    String heartrate = smsg;
                    TextView textView = findViewById(R.id.textViewHeartrate);
                    textView.setText(heartrate.substring(intIndex1+11,heartrate.indexOf("#",intIndex1)));   //显示数据
                }

                int intIndex2 = smsg.indexOf("$Spo2:");
                if(intIndex2!=-1) {
                    String spo2 = smsg;
                    TextView textView = findViewById(R.id.textViewSpo2);
                    if (spo2.substring(intIndex2 + 6, spo2.indexOf("#", intIndex2)).equals("3")) {
                        textView.setText("0");   //显示数据

                    } else {
                        textView.setText(spo2.substring(intIndex2 + 6, spo2.indexOf("#", intIndex2)));   //显示数据

                    }
                }

                int intIndex3 = smsg.indexOf("$Temperature:");
                if(intIndex3!=-1) {
                    String temperature = smsg;
                    TextView textView = findViewById(R.id.textViewTemperature);
                    textView.setText(temperature.substring(intIndex3+13,temperature.indexOf("#",intIndex3)));   //显示数据
                }

                int intIndex4 = smsg.indexOf("$Steps:");
                if(intIndex4!=-1) {
                    String Steps = smsg;
                    TextView textView = findViewById(R.id.textViewSteps);
                    textView.setText(Steps.substring(intIndex4+7,Steps.indexOf("#",intIndex4)));   //显示数据
                }

                int intIndex5 = smsg.indexOf("$Mileage:");
                if(intIndex5!=-1) {
                    String mileage = smsg;
                    TextView textView = findViewById(R.id.textViewMileage);
                    textView.setText(mileage.substring(intIndex5+9,mileage.indexOf("#",intIndex5)));   //显示数据
                }

                int intIndex6 = smsg.indexOf("$Hour:");
                if(intIndex6!=-1) {
                    String hour = smsg;
                    TextView textView = findViewById(R.id.textViewMotionHour);
                    textView.setText(hour.substring(intIndex6+6,hour.indexOf("#",intIndex6)));   //显示数据
                }

                int intIndex7 = smsg.indexOf("$Min:");
                if(intIndex7!=-1) {
                    String min = smsg;
                    TextView textView = findViewById(R.id.textViewMotionMin);
                    textView.setText(min.substring(intIndex7+5,min.indexOf("#",intIndex7)));   //显示数据
                }

                int intIndex8 = smsg.indexOf("$Sec:");
                if(intIndex8!=-1) {
                    String sec = smsg;
                    TextView textView = findViewById(R.id.textViewMotionSec);
                    textView.setText(sec.substring(intIndex8+5,sec.indexOf("#",intIndex8)));   //显示数据
                }

                int intIndex11 = smsg.indexOf("$setHeartMax:");
                if(intIndex11!=-1) {
                    String smsg1 = smsg;
                    TextView textView = findViewById(R.id.textViewSetHeartrateMax);
                    String str = smsg1.substring(intIndex11+13,smsg1.indexOf("#",intIndex11));
                    setHeartrateMaxValue = Integer.valueOf(str);
                    textView.setText(str);   //显示数据
                }

                int intIndex12 = smsg.indexOf("$setSpo2Min:");
                if(intIndex12!=-1) {
                    String smsg1 = smsg;
                    TextView textView = findViewById(R.id.textViewSpo2Min);
                    String str = smsg1.substring(intIndex12+12,smsg1.indexOf("#",intIndex12));
                    setSpo2MinValue = Integer.valueOf(str);
                    textView.setText(str);   //显示数据
                }

                int intIndex13 = smsg.indexOf("$setTempMin:");
                if(intIndex13!=-1) {
                    String smsg1 = smsg;
                    TextView textView = findViewById(R.id.textViewTempMin);
                    String str = smsg1.substring(intIndex13+12,smsg1.indexOf("#",intIndex13));
                    setTempMinValue = Float.parseFloat(str);
                    textView.setText(str);   //显示数据
                }

                int intIndex14 = smsg.indexOf("$setTempMax:");
                if(intIndex14!=-1) {
                    String smsg1 = smsg;
                    TextView textView = findViewById(R.id.textViewTempMax);
                    String str = smsg1.substring(intIndex14+12,smsg1.indexOf("#",intIndex14));
                    setTempMaxValue = Float.parseFloat(str);
                    textView.setText(str);   //显示数据
                }

                int intIndex15 = smsg.indexOf("$setLength:");
                if(intIndex15!=-1) {
                    String smsg1 = smsg;
                    TextView textView = findViewById(R.id.textViewSetSteps);
                    String str = smsg1.substring(intIndex15+11,smsg1.indexOf("#",intIndex15));
                    setLengthValue = Integer.valueOf(str);
                    textView.setText(str);   //显示数据
                }

                int intIndex16 = smsg.indexOf("$setMileage:");
                if(intIndex16!=-1) {
                    String smsg1 = smsg;
                    TextView textView = findViewById(R.id.textViewSetMileage);
                    String str = smsg1.substring(intIndex16+12,smsg1.indexOf("#",intIndex16));
                    setMileageValue = Float.parseFloat(str);
                    textView.setText(str);   //显示数据
                }

                int intIndex9 = smsg.indexOf("$setHeartMin:");
                if(intIndex9!=-1) {
                    String smsg1 = smsg;
                    TextView textView = findViewById(R.id.textViewSetHeartrateMin);
                    String str = smsg1.substring(intIndex9+13,smsg1.indexOf("#",intIndex9));
                    setHeartrateMinValue = Integer.valueOf(str);
                    textView.setText(str);   //显示数据
                }

                smsg="";
            }catch (Exception e){
                e.printStackTrace();
            }

        }
    };

    @SuppressLint("MissingPermission")
    public void onConnectButtonClicked(View view) {
        if(_bluetooth.isEnabled()==false){  //如果蓝牙服务不可用则提示
            Toast.makeText(this, " 打开蓝牙中...", Toast.LENGTH_SHORT).show();
            _bluetooth.enable();
            return;
        }
        //如未连接设备则打开DeviceListActivity进行设备搜索
        if(_socket==null){
            Intent serverIntent = new Intent(this, DeviceListActivity.class); //跳转程序设置
            startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);  //设置返回宏定义
        }
    }

    public void onDisconnectionClicked(View view) {
        //关闭连接socket
        if(_socket!=null) {
            try {
                Toast.makeText(this, " 蓝牙断开", Toast.LENGTH_SHORT).show();

                bRun = false;
                //is.close();
                _socket.close();
                _socket = null;

            }
            catch (IOException e) {}
        }
    }

    public void onExitButtonClicked(View view) {
        //---安全关闭蓝牙连接再退出，避免报异常----//
        if(_socket!=null){
            //关闭连接socket
            try{
                bRun = false;
                //is.close();
                _socket.close();
                _socket = null;
            }catch(IOException e){}
        }
        finish();     //退出APP
    }

    public void onSendButtonClicked(View view) {
        int i=0;
        int n=0;
        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }

        TextView edit0 = findViewById(R.id.reminderTimeHour);
        TextView edit1 = findViewById(R.id.reminderTimeMin);
        TextView edit2 = findViewById(R.id.reminderTimeSec);

        if(edit0.getText().length()==0){
            Toast.makeText(this, "请先输入数据", Toast.LENGTH_SHORT).show();
            return;
        }
        if(edit1.getText().length()==0){
            Toast.makeText(this, "请先输入数据", Toast.LENGTH_SHORT).show();
            return;
        }
        if(edit2.getText().length()==0){
            Toast.makeText(this, "请先输入数据", Toast.LENGTH_SHORT).show();
            return;
        }
        try{
            OutputStream os = _socket.getOutputStream();   //蓝牙连接输出流

            byte[] bos1 = edit0.getText().toString().getBytes();
            byte[] bos2 = edit1.getText().toString().getBytes();
            byte[] bos3 = edit2.getText().toString().getBytes();

            byte[] send_bos = new byte[100];

            send_bos[i++]='w';send_bos[i++]='a';send_bos[i++]='r';send_bos[i++]='n';
            send_bos[i++]='t';send_bos[i++]='i';send_bos[i++]='m';send_bos[i++]='e';

            n = i;
            for(i=0;i<bos1.length;i++) {
                send_bos[n+i]=bos1[i];
            }
            n += i;
            send_bos[n++]=':';

            for(i=0;i<bos2.length;i++) {
                send_bos[n+i]=bos2[i];
            }
            n += i;
            send_bos[n++]=':';

            for(i=0;i<bos3.length;i++) {
                send_bos[n+i]=bos3[i];
            }
            n += i;
            send_bos[n++]=0x0d;
            send_bos[n++]=0x0a;

            os.write(send_bos);

        }catch(IOException e){
        }
    }

    public void onAddHeartrateMinClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setHeartrateMaxValue-setHeartrateMinValue>1) setHeartrateMinValue++;
        String s = new String(String.valueOf(setHeartrateMinValue));
        str1+=s;
        TextView textView = findViewById(R.id.textViewSetHeartrateMin);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+14];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='H';bos2[i++]='e';bos2[i++]='a';
            bos2[i++]='r';bos2[i++]='t';bos2[i++]='M';bos2[i++]='i';bos2[i++]='n';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onDecHeartrateMinClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setHeartrateMinValue>0) setHeartrateMinValue--;
        String s = new String(String.valueOf(setHeartrateMinValue));
        str1+=s;
        TextView textView = findViewById(R.id.textViewSetHeartrateMin);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+14];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='H';bos2[i++]='e';bos2[i++]='a';
            bos2[i++]='r';bos2[i++]='t';bos2[i++]='M';bos2[i++]='i';bos2[i++]='n';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onAddHeartrateMaxClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setHeartrateMaxValue<300) setHeartrateMaxValue++;
        String s = new String(String.valueOf(setHeartrateMaxValue));
        str1+=s;
        TextView textView = findViewById(R.id.textViewSetHeartrateMax);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+14];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='H';bos2[i++]='e';bos2[i++]='a';
            bos2[i++]='r';bos2[i++]='t';bos2[i++]='M';bos2[i++]='a';bos2[i++]='x';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onDecHeartrateMaxClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setHeartrateMaxValue-setHeartrateMinValue>1) setHeartrateMaxValue--;
        String s = new String(String.valueOf(setHeartrateMaxValue));
        str1+=s;
        TextView textView = findViewById(R.id.textViewSetHeartrateMax);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+14];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='H';bos2[i++]='e';bos2[i++]='a';
            bos2[i++]='r';bos2[i++]='t';bos2[i++]='M';bos2[i++]='a';bos2[i++]='x';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onAddSpo2MinClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setSpo2MinValue<200) setSpo2MinValue++;
        String s = new String(String.valueOf(setSpo2MinValue));
        str1+=s;
        TextView textView = findViewById(R.id.textViewSpo2Min);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+13];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='S';bos2[i++]='p';bos2[i++]='o';
            bos2[i++]='2';bos2[i++]='M';bos2[i++]='i';bos2[i++]='n';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onDecSpo2MinClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setSpo2MinValue>0) setSpo2MinValue--;
        String s = new String(String.valueOf(setSpo2MinValue));
        str1+=s;
        TextView textView = findViewById(R.id.textViewSpo2Min);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+13];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='S';bos2[i++]='p';bos2[i++]='o';
            bos2[i++]='2';bos2[i++]='M';bos2[i++]='i';bos2[i++]='n';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onAddTempMinClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setTempMaxValue-setTempMinValue>0.1F) setTempMinValue=setTempMinValue+0.1F;
        String s =  String.format("%.1f", setTempMinValue);
        str1+=s;
        TextView textView = findViewById(R.id.textViewTempMin);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+13];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='T';bos2[i++]='e';bos2[i++]='m';
            bos2[i++]='p';bos2[i++]='M';bos2[i++]='i';bos2[i++]='n';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onDecTempMinClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setTempMinValue>=0.1F) setTempMinValue=setTempMinValue-0.1F;
        String s =  String.format("%.1f", setTempMinValue);
        str1+=s;
        TextView textView = findViewById(R.id.textViewTempMin);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+13];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='T';bos2[i++]='e';bos2[i++]='m';
            bos2[i++]='p';bos2[i++]='M';bos2[i++]='i';bos2[i++]='n';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                    bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onAddTempMaxClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setTempMaxValue<99.9F) setTempMaxValue=setTempMaxValue+0.1F;
        String s =  String.format("%.1f", setTempMaxValue);
        str1+=s;
        TextView textView = findViewById(R.id.textViewTempMax);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+13];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='T';bos2[i++]='e';bos2[i++]='m';
            bos2[i++]='p';bos2[i++]='M';bos2[i++]='a';bos2[i++]='x';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onDecTempMaxClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setTempMaxValue-setTempMinValue>0.1F)  setTempMaxValue=setTempMaxValue-0.1F;
        String s =  String.format("%.1f", setTempMaxValue);
        str1+=s;
        TextView textView = findViewById(R.id.textViewTempMax);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+13];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='T';bos2[i++]='e';bos2[i++]='m';
            bos2[i++]='p';bos2[i++]='M';bos2[i++]='a';bos2[i++]='x';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }

    }

    public void onAddStepsClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setLengthValue<200) setLengthValue++;
        String s = new String(String.valueOf(setLengthValue));
        str1+=s;
        TextView textView = findViewById(R.id.textViewSetSteps);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+11];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='S';bos2[i++]='t';
            bos2[i++]='e';bos2[i++]='p';bos2[i++]='s';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onDecStepsClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setLengthValue>0) setLengthValue--;
        String s = new String(String.valueOf(setLengthValue));
        str1+=s;
        TextView textView = findViewById(R.id.textViewSetSteps);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+11];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='S';bos2[i++]='t';
            bos2[i++]='e';bos2[i++]='p';bos2[i++]='s';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onAddMileageClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setMileageValue<20.00F) setMileageValue=setMileageValue+0.01F;
        String s =  String.format("%.2f", setMileageValue);
        str1+=s;
        TextView textView = findViewById(R.id.textViewSetMileage);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+13];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='M';bos2[i++]='i';bos2[i++]='l';
            bos2[i++]='e';bos2[i++]='a';bos2[i++]='g';bos2[i++]='e';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onDecMileageClicked(View view) {
        String str1 = "";    //显示用数据缓存
        int i=0;
        int n=0;

        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        if(setMileageValue>=00.01F) setMileageValue=setMileageValue-0.01F;
        String s =  String.format("%.2f", setMileageValue);
        str1+=s;
        TextView textView = findViewById(R.id.textViewSetMileage);
        textView.setText(str1);
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] bos1 = textView.getText().toString().getBytes();
            byte[] bos2 = new byte[bos1.length+13];
            bos2[i++]='s';bos2[i++]='e';bos2[i++]='t';bos2[i++]='M';bos2[i++]='i';bos2[i++]='l';
            bos2[i++]='e';bos2[i++]='a';bos2[i++]='g';bos2[i++]='e';bos2[i++]=':';
            n = i;
            for(i=0;i<bos1.length;i++) {
                bos2[n+i]=bos1[i];
            }
            n += i;
            bos2[n++]=0x0d;
            bos2[n++]=0x0a;
            os.write(bos2);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onStepsClearButClicked(View view) {
        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] send_bos = {'s','t','e','p','s','C','l','e','a','r',0x0d,0x0a};
            os.write(send_bos);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onMileageClearButClicked(View view) {
        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] send_bos = {'m','i','l','e','a','g','e','C','l','e','a','r',0x0d,0x0a};
            os.write(send_bos);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onTimeClearButClicked(View view) {
        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] send_bos = {'t','i','m','e','C','l','e','a','r',0x0d,0x0a};
            os.write(send_bos);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onStartTimingButClicked(View view) {
        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] send_bos = {'s','t','a','r','t','T','i','m','i','n','g',0x0d,0x0a};
            os.write(send_bos);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onPauseTimingButClicked(View view) {
        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] send_bos = {'p','a','u','s','e','T','i','m','i','n','g',0x0d,0x0a};
            os.write(send_bos);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onOffMileageWarnClicked(View view) {
        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] send_bos = {'o','f','f','M','i','l','e','a','g','e',0x0d,0x0a};
            os.write(send_bos);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void onOffTimeWarnClicked(View view) {
        if(_socket==null){
            Toast.makeText(this, "请先连接蓝牙模块", Toast.LENGTH_SHORT).show();
            return;
        }
        try{
            //蓝牙连接输出流
            OutputStream os = _socket.getOutputStream();
            byte[] send_bos = {'o','f','f','T','i','m','e',0x0d,0x0a};
            os.write(send_bos);
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
